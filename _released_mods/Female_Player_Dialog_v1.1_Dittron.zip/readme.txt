		Female Player Dialog for Link's Awakening DX HD
		by Dittron

	1.) Overview
--------------------------------------------------------------------------------------------------------
		This mod tweaks the game dialog to be more suitable for a female protagonist. 
		
		There are two versions:
		 
		- The "Normal" version that tries to be vanilla friendly and only change what's necessary 
		  (boy to girl, lad to lass, etc.). Pairs well with female player replacement mods that don't 
		  include their own dialog changes. Use this version if you want to keep as many of the original
		  lines intact as possible. Supports English and Spanish.*
		
		- The "Alternative" version goes a step further and attempts to rewrite certain lines (that were 
		  intended for a boy protagonist) to be more gender-neutral. Many of the changes were made by 
		  referencing other translations of the game, however some creative liberties were still taken. 
		  Use this version if you want a more "immersive" experience. English Only
		  
		* The Spanish version was made with the help of machine translation and my surface level
		  knowledge of the language. Expect there to be mistakes or missing lines. 


	2.) Installation 
--------------------------------------------------------------------------------------------------------
		Requires LADXHD v1.8.2 or higher. Choose either the Normal or the Alternative version of the mod
		and install the corresponding .lahdpak file using the game's Launcher.


	3.) Dialog Changes
--------------------------------------------------------------------------------------------------------
		Inserting a female protagonist into the story in a believable way requires more than just 
		changing pronouns. That's where the Alternative version comes in. The goal of this version is to 
		make the script a bit more gender-neutral. This means rewriting certain lines to reduce the 
		amount of romantic or suggestive implications involving the protagonist. Many of the changes 
		were made by referencing other translations of the script to try to keep it as "official" as 
		possible. However, some creative liberties are taken in a few instances.

		I'm going to run through a few examples from the Alternative version just to highlight some of the 
		changes and why they were made:
		
		- Example 1 - Marin during the beach scene

			Original: 	"I want to know everything about you...Err...Uhh, Ha ha ha ha!"
		
			Modded:		"Someday I'd like to visit the place you're from. Oh, sometimes I say such 
						silly things... Heh, heh..."

		This line is pulled from the Spanish translation, which is itself a more faithful version of the 
		Japanese line. Apparently this is supposed to be a love confession in Japanese but it doesn't 
		carry the same meaning in English so let's go with it here.

		- Example 2 - When speaking to the village boys with Marin following you

			Original:	"Hey... Where're you two going together? Hunh? Uh, I didn't mean anything...
						I'm just a kid!"
						
			Modded:		"There are some things around here that you can only do with a pal!
						Don't ask me what that means, I'm just a kid!"

		This is a tough one. The kids are clearly teasing you about being on a "date." It's the same in 
		every version of the script that I could check so there's no official alternative here. 
		Considering the goals of this version, leaving it doesn't feel right so we'll have to come up 
		with something original. 
		
		The boys often give the player hints then follow it up with "I'm just a kid." Since there are 
		missable events during this section of the game, the new line hints for you to explore with 
		Marin as a follower. I'm not a fan of completely changing the line but at least it's more 
		useful now.

		- Example 3 - *That* interaction with Martha the mermaid

			Original:	"Kyaa! Pervert! Perveeert!!!"
		
			Modded:		"No scales before I have my bra back!"

		So... in the Redux (uncensored) version of the script, the mermaid is missing her bra instead of
		her necklace. This particular line happens if you dive under the water next to her before 
		finding her bra. She (understandably) screams at Link, but I don't feel like she'd have the 
		same reaction with a female character. This replacement line is taken from the Switch version 
		except "necklace" is replaced with "bra" of course. It's an official line modified to refer to 
		the Redux item so it works.


	4.) Final Thoughts
--------------------------------------------------------------------------------------------------------
		One of my favorite types of mods are ones that allow you to play as a new character. It's a 
		simple way to make a familiar game feel fresh again without losing what made the game special 
		to begin with. It gets more complicated when inserting a female protagonist into a story like 
		Link's Awakening since the game's script was written around Link. I wanted to make playing as a 
		new character believable, as if it was originally written with a female protagonist in mind. At 
		the same time I wanted to avoid overstepping and the mod feeling too much like fanfiction. Some 
		players might even be perfectly fine with the original script and I wouldn't want to force 
		unnecessary changes onto them. So, there are two separate versions. Overall I think that I was 
		able to find a good balance but I am open to suggestions for improvement. I'd love to get some 
		feedback as this has been a solo project up to this point. 
		
		To the modders out there: if you plan on making a female character mod, feel free to include 
		these script changes in your mod or use it as a base to make your own. I'm not looking for
		credit just don't claim it as your own I guess. Also if you're fluent in another language and
		want to provide translations I'd be thrilled to include them in this mod.

		Anyway, thanks for reading this! I've put a lot of time and thought into this so I hope it can 
		enhance your experience when playing this classic adventure in some small but meaningful way.


	5.) Sources
--------------------------------------------------------------------------------------------------------
		Álcam & IPeluchito - Spanish translation for LADXHD
		
		Elizabeth Bushouse - Zelda: Link’s Awakening Script Comparison
							 (https://lizbushouse.com/zelda-links-awakening-script-comparison/)
							 
							 
	6.) Changelog
--------------------------------------------------------------------------------------------------------

	v1.0 - Initial release
	
	v1.1 - Converted mod into the installable .lahdpak format
		   Renamed "Lite" and "Extended" to "Normal" and "Alternative" respectively
		   Cut several lines from the Alternative version as I didn't feel they were necessary